var app = angular.module('aplicacion', []); //Declara el nombre de la aplicacion
app.controller('PrincipalCtrl', function ($scope, $http) { //$http realiza peticiones al servidor; $scope
    /*$scope.ejemplo = "Hola Mundo"; //crea una variable con el nombre "ejemplo" de $scope
    let principal = this;
    principal.equipos = [];
    $http.get("https://worldcup.sfg.io/matches/today")
        .then(function (response) {
            for (var j = 0; j < response.data.length; j++) {
                principal.equipos.push(response.data[j].location)
            }
        });
})
app.controller('EjemploCtrl', function ($scope) {
    $scope.data = [{
            pais: "Colombia",
            capital: "Bogota"
        },
        {
            pais: "Venezuela",
            capital: "Caracas"
        },
        {
            pais: "Peru",
            capital: "Lima"
        },
        {
            pais: "Rusia",
            capital: "Moscu"
        }
    ]
    $scope.informacionAmostrar = [];
    for (var i = 0; i < $scope.data.length; i++) {
        $scope.informacionAmostrar.push($scope.data[i].pais)
    }
});
*/

    let principal = this;
   principal.equipos = [];

    $http.get("https://worldcup.sfg.io/matches/today")
        .then(function (response) {
            for (var j = 0; j < response.data.length; j++) { 
                for(var i=0;i<response.data.length;i++){                            
             principal.equipos.local.push(response.data[j].home_team_country)
             principal.equipos.visitante.push(response.data[i].away_team_country)
                }
            }
        });
})